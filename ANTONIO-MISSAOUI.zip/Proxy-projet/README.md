# Proxy-projet

 avant de lancer le proxy configurer le firefox pour qu'il utilise le proxy
 selon l'image en dessous


 ![config proxy](proxy.png)
